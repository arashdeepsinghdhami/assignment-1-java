

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Excel {
    private ArrayList<Double> numbers;

    public Excel(ArrayList<Double> numbers) {
        this.numbers = numbers;
    }

    public Excel(String inputString) {
        String[] strNumArray = inputString.split(" ");
        List<String> strNumList = Arrays.asList(strNumArray);

        numbers = new ArrayList<>();
        for (String strNum : strNumList) {
            numbers.add(Double.parseDouble(strNum));
        }
    }

    public double findTotal() {
        double total = 0;
        for (double num : numbers) {
            total += num;
        }
        return total;
    }

    public double findAverage() {
        double total = findTotal();
        return total / numbers.size();
    }

    public double findMax() {
        double max = numbers.get(0);
        for (double num : numbers) {
            if (num > max) {
                max = num;
            }
        }
        return max;
    }

    public double findMin() {
        double min = numbers.get(0);
        for (double num : numbers) {
            if (num < min) {
                min = num;
            }
        }
        return min;
    }
}
