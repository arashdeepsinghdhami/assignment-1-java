

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class SwingEventWindow extends JFrame implements ActionListener, ItemListener {
    private int rdoChecked = 1; // 1 represents the first radio button selected by default
    private JPanel mainPanel;
    private JPanel panel1;
    private JPanel panel2;
    private JPanel panel3;
    private JPanel panel4;
    private JPanel panel5;
    private JPanel panel6;
    private JLabel lblMain;
    private JLabel lblRequest;
    private JTextField txtNum;
    private JRadioButton rdoTotal;
    private JRadioButton rdoAvg;
    private JRadioButton rdoMax;
    private JRadioButton rdoMin;
    private JButton btnCalculate;
    private JLabel lblResult;
    private JTextField txtResult;

    public SwingEventWindow() {
        setTitle("Excel Calculation");
        setSize(400, 300);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mainPanel = new JPanel();
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        panel4 = new JPanel();
        panel5 = new JPanel();
        panel6 = new JPanel();

        lblMain = new JLabel("Excel Calculation");
        lblRequest = new JLabel("Enter space-separated numbers:");
        txtNum = new JTextField(20);

        rdoTotal = new JRadioButton("Total");
        rdoAvg = new JRadioButton("Average");
        rdoMax = new JRadioButton("Maximum");
        rdoMin = new JRadioButton("Minimum");

        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(rdoTotal);
        buttonGroup.add(rdoAvg);
        buttonGroup.add(rdoMax);
        buttonGroup.add(rdoMin);

        btnCalculate = new JButton("Calculate");

        lblResult = new JLabel("Result:");
        txtResult = new JTextField(10);
        txtResult.setEditable(false);

        panel1.add(lblMain);
        panel2.add(lblRequest);
        panel3.add(txtNum);
        panel4.add(rdoTotal);
        panel4.add(rdoAvg);
        panel4.add(rdoMax);
        panel4.add(rdoMin);
        panel5.add(btnCalculate);
        panel6.add(lblResult);
        panel6.add(txtResult);

        mainPanel.setLayout(new GridLayout(6, 1));
        mainPanel.add(panel1);
        mainPanel.add(panel2);
        mainPanel.add(panel3);
        mainPanel.add(panel4);
        mainPanel.add(panel5);
        mainPanel.add(panel6);

        add(mainPanel);

        rdoTotal.addItemListener(this);
        rdoAvg.addItemListener(this);
        rdoMax.addItemListener(this);
        rdoMin.addItemListener(this);
        btnCalculate.addActionListener(this);
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getSource() == rdoTotal && rdoTotal.isSelected()) {
            rdoChecked = 1;
        } else if (e.getSource() == rdoAvg && rdoAvg.isSelected()) {
            rdoChecked = 2;
        } else if (e.getSource() == rdoMax && rdoMax.isSelected()) {
            rdoChecked = 3;
        } else if (e.getSource() == rdoMin && rdoMin.isSelected()) {
            rdoChecked = 4;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnCalculate) {
            String inputString = txtNum.getText();
            Excel excel = new Excel(inputString);

            if (rdoChecked == 1) {
                double total = excel.findTotal();
                txtResult.setText(String.valueOf(total));
            } else if (rdoChecked == 2) {
                double average = excel.findAverage();
                txtResult.setText(String.valueOf(average));
            } else if (rdoChecked == 3) {
                double max = excel.findMax();
                txtResult.setText(String.valueOf(max));
            } else if (rdoChecked == 4) {
                double min = excel.findMin();
                txtResult.setText(String.valueOf(min));
            }
        }
    }
}
